public class Cyclist extends Athlete {

}
