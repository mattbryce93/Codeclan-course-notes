package device_management;

public class TypeWriter extends PrintingDevice {

    public TypeWriter(String make, String model) {
        super(make, model);
    }
}
